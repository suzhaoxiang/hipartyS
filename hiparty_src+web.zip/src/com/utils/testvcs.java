package com.utils;

/**
 * Created by lurunfa on 2017/4/2.
 *
 * @author lurunfa
 * @version 1.0
 */
public class testvcs {
    private String test;
    private String hi;
}
