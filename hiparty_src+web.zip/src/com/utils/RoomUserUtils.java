package com.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/4/16.
 */
public class RoomUserUtils {
    /**
     * 关于你比划我猜的方法
     */
    private List<String> gameWordslist=new ArrayList<>();


}
